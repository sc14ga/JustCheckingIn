//
//  ViewController.m
//  Just Checking In
//
//  Created by Georgios Aikaterinakis [sc14ga] on 08/05/2015.
//  Copyright (c) 2015 Georgios Aikaterinakis [sc14ga]. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
