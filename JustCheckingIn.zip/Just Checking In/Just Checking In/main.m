//
//  main.m
//  Just Checking In
//
//  Created by Georgios Aikaterinakis [sc14ga] on 08/05/2015.
//  Copyright (c) 2015 Georgios Aikaterinakis [sc14ga]. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
