//
//  AppDelegate.h
//  Just Checking In
//
//  Created by Georgios Aikaterinakis [sc14ga] on 08/05/2015.
//  Copyright (c) 2015 Georgios Aikaterinakis [sc14ga]. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

